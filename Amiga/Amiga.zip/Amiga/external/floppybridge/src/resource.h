//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by Resource.rc
//
#define IDB_BRIDGELOGO0                 101
#define IDB_BRIDGELOGO1                 102
#define IDB_BRIDGELOGO2                 103
#define IDD_PROFILEEDITOR               104
#define IDB_BITMAP1                     108
#define IDB_PATREON                     108
#define IDD_PROFILELISTEDITOR           109
#define IDC_LIST1                       1001
#define IDCREATE                        1004
#define IDC_PROFILENAME                 1004
#define IDEDIT                          1005
#define IDC_DRIVER                      1005
#define IDDELETE                        1006
#define IDC_MODE                        1006
#define IDCREATE2                       1007
#define IDC_DISKTYPE                    1007
#define IDC_SMART                       1008
#define IDC_CABLE                       1009
#define IDC_COMPORT                     1010
#define IDC_AUTOCACHE                   1011
#define IDC_URL                         1012
#define IDC_AUTODETECT                  1013
#define IDC_URL_MAIN                    1014
#define IDC_PATREON                     1019
#define IDC_PROFILELIST_TITLE           1200
#define IDC_CHECKUPDATES                1202

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        109
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1015
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
