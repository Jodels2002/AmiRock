SPS DECODER LIBRARY (SPStudio_Dev) v5.1 SOURCE CODE release package

This distribution contains the source code for the SPS DECODER LIBRARY v5.1 for Windows(tm), Mac OS X(tm) and Linux. This not free software, please read the licence.



If you encounter any problems, please let us know by posting here:

http://forum.kryoflux.com


Please use the forums for bug reports, do not submit tickets for this.


Thank you for your support,
The Software Preservation Society